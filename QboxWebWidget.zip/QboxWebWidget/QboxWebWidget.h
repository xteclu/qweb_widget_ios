//
//  qweb_widget.h
//  qweb-widget
//
//  Created by Nurken Tileubergenov on 21.10.2022.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

//! Project version number for qweb_widget.
FOUNDATION_EXPORT double qweb_widgetVersionNumber;

//! Project version string for qweb_widget.
FOUNDATION_EXPORT const unsigned char qweb_widgetVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <qweb_widget/PublicHeader.h>


